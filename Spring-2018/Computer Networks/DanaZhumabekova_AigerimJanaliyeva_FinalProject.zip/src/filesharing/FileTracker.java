/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesharing;

import java.util.*;
import java.net.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 *
 * @author zuldyz
 */
public class FileTracker {

    public static String FileTrackerIP = "10.110.116.203";
    public static int FileTrackerPort = 7777;
    public static Map<String, List<String>> records = Collections.synchronizedMap(new HashMap<>());
    public static Map<String, List<Client>> peers = Collections.synchronizedMap(new HashMap<>());
    static int numberOfPeers = 0; // counter for clients

    public Map<String, List<String>> getRecords() {
        return records;
    }

    public static synchronized boolean searchRecords(String filename) {
        if (records.containsKey(filename)) {
            System.out.println("Found!");

        } else {
            return false;
        }
        return true;
    }

    public static synchronized int findScore(String ip, int port) {

        for (Client p : peers.get(ip)) {
            if (p.getPort() == port) {
                return p.getScore();
            }

        }

        return 0;
    }

    public static synchronized boolean addRecord(String filename, String data) {
        if (!records.containsKey(filename)) {
            List<String> d = new CopyOnWriteArrayList<>();
            d.add(data);
            records.put(filename, d);
        } else {
            records.get(filename).add(data);
        }
        System.out.println(records);
        System.out.println(peers);
        return true;
    }

    public static synchronized boolean removeRecord(Client c) {
        System.out.println("Pev hash: " + records);
        for (Map.Entry<String, List<String>> entry : records.entrySet()) {
            String key = entry.getKey();
            List<String> value = entry.getValue();
            for (String s : c.getFdata()) {
                for (String inhash : value) {
                    if (s.equals(inhash)) {
                        System.out.println("Key: " + key + " Value: " + inhash);
                        records.get(key).remove(inhash);
                    }
                }
            }

        }
        System.out.println("New hash: " + records);
        for (Iterator<Map.Entry<String, List<String>>> it = records.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String, List<String>> entry = it.next();
            if (entry.getValue().isEmpty()) {
                it.remove();
            }
        }

        System.out.println("Last hash: " + records);
        return true;
    }

    public static synchronized boolean addPeer(Client c) {
        if (!peers.containsKey(c.getIP())) {
            Client p = c;
            List<Client> ps = new CopyOnWriteArrayList<>();
            ps.add(p);
            peers.put(c.getIP(), ps);

        } else {
            System.out.println("Peers before3.5: ");
            for (Client pr : peers.get(c.getIP())) {
                System.out.println("port: " + pr.getPort());
                if (pr.getPort() != c.getPort()) {
                    Client cl = c;
                    peers.get(c.getIP()).add(cl);
                    break;
                }
            }
            System.out.println("Peers before4: ");
            System.out.println(peers);
        }

        System.out.println("New and old peers: ");
        System.out.println(peers);
        return true;
    }

    public static void main(String argv[]) throws Exception {

        ServerSocket welcomeSocket = new ServerSocket(7777);

        while (true) {
            Socket sock = welcomeSocket.accept();
            System.out.println("New client has arrived: \n" + sock.getPort());
            PeerHandler clThread = new PeerHandler(sock, numberOfPeers);
            Thread td = new Thread(clThread);
            td.start();
            numberOfPeers++;

        }
    }

}
