/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesharing;

import java.util.ArrayList;

/**
 *
 * @author zuldyz
 */
public class Client {
    
    private String ip;
    private int port;
    private int score;
    private  ArrayList<String> fs;
    private int NumOfRequests;
    private int NumOfUploads;

    public Client(String ip, int port, int score) {
        this.ip = ip;
        this.port = port;
        this.score = score;
        fs = new ArrayList<>();
        //this.fs = fs;
    }

    public String getIP() {
        return ip;
    }

    public ArrayList<String> getFdata() {
        return fs;
    }

    public int getScore() {
        return score;
    }

    public int getPort() {
        return port;
    }
    

    public int getNumOfRequests() {
        return NumOfRequests;
    }

    public int getNumOfUploads() {
        return NumOfUploads;
    }

    public void setScore(int n) {
        score = n;
    }

    public void setNumOfRequests(int n) {
        NumOfRequests = n;
    }

    public void setNumOfUploads(int n) {
        NumOfUploads = n;
    }

    @Override
    public String toString() {
        return "<" + ip + ", " + port + ", " + score + ">";
    }
//    public ArrayList<FData> getList(){
//        return fs;
//    }
    
}
