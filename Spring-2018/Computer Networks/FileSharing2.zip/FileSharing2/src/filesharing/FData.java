/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesharing;

class FData {
    private String name;
    private String type;
    private String lastModified;
    private int size;
    private String clientIP;
    private int clientPort;
    
    
    public FData(String name, String type,int size, String lastModified, String clientIP, int clientPort) {
        this.name = name;
        this.type = type;
        this.size = size;
        this.lastModified = lastModified;
        this.clientIP = clientIP;
        this.clientPort = clientPort;  
    }
    
    public String getName() {
        return name;
    }
    
    public long getSize() {
        return size;
    }

    public String getType() {
        return type;
    }
    @Override
    public String toString(){
        return "<" + name + ", " + type + ", " + size + ", " + lastModified + ", " + clientIP + ", " + clientPort +">";
    }
}
