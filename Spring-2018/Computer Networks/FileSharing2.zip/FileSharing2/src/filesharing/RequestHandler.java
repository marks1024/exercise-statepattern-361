/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesharing;

import java.io.*;
import java.net.Socket;
import java.util.*;

/**
 *
 * @author zuldyz
 */
public class RequestHandler implements Runnable {

    Socket sock;
    BufferedReader dis;
    OutputStream out;
    File[] files;

    public RequestHandler(Socket sock, File[] files) {
        try {
            this.sock = sock;
            this.files = files;
            out = sock.getOutputStream();
            dis = new BufferedReader(new InputStreamReader(sock.getInputStream()));

        } catch (IOException ex) {
            System.out.println("Cannot open stream!");
        }

    }

    @Override
    public void run() {
        String received = "";
        int n;
        System.out.println("Hello!");
        boolean done = false;
        try{
        while (done == false) {
            try {

                received = dis.readLine();
                System.out.println("I received: " + received);
                if (received.startsWith("NO!")) {
                    System.out.println("NO?");
                } else {
                    handleMessages(received);
                    done = true;
                }

            } catch (IOException ex) {
                System.out.println("Cannot read!");
            }

        }
        }finally{
            try {
                    dis.close();
                    out.close();
                    sock.close();
                } catch (IOException ex) {
                    System.out.println("Failed to close the socket");
                }
        }
    }

    private boolean handleMessages(String received) {
        //String strs[] = received.split(" ", 2);
        String downMessage[] = received.split(": ");
        if (downMessage[0].equals("DOWNLOAD")) {
            answerRequest(received);
            System.out.println(received);
        } else {
            if (received.equals("[]")) {
                System.out.println("EMPTY");
                try {
                    dis.close();
                    out.close();
                    sock.close();
                } catch (IOException ex) {
                    System.out.println("Failed to close the socket");
                }
                return true;
            }

        }
        return false;

    }

    private void answerRequest(String received) {
        String strs[] = received.split(" ");
        System.out.println("I am answering...");
        System.out.println("received..." + received);

        String fname = strs[1];
        System.out.println("fname: " + fname);
        String type = strs[2];
        System.out.println("type: " + type);
        System.out.println("Size: " + strs[3]);
        String s2[] = strs[3].split("\"");
        System.out.println("This size: " + s2[0]);
        int size = Integer.parseInt(s2[0]);
        Random rand = new Random();
        int p = rand.nextInt((100 - 0) + 1);
        p = 40;
        if (p > 50) {
            try {
                out.write(("NO!\n").getBytes());
                System.out.println("Permission denied!");

            } catch (IOException ex) {
                System.out.println("Cannot write!");
            }
        } else {
            sendFile(fname, type, size);

        }

    }

    private void sendFile(String fname, String type, int size) {
        File requestedFile = null;
        for (File f : files) {
            if (f.getName().equals(fname)) {
                System.out.println("I found this file....");
                requestedFile = f;
            }
        }

        try {
            FileInputStream fileStream = new FileInputStream(requestedFile);
            byte[] fileBytes = new byte[(int) requestedFile.length()];
            System.out.println("File bytes: " + fileBytes);
            System.out.println("I am sending...");
            out.write("FILE:\n".getBytes(), 0, 5);
            int cc;
            while ((cc = fileStream.read(fileBytes)) > 0) {
                out.write(fileBytes, 0, cc);
            }

        } catch (IOException ex) {
            System.out.println("Cannot read a file!");
        }
    }
}
