package filesharing;


import java.io.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

/**
 *
 * @author zuldyz
 */
public class Peer extends JFrame implements ActionListener {

    private String ip;
    private int port;
    private int score;
    private static ArrayList<FData> fs;
    private static boolean isAccepted = false;
    private static boolean isDone = false;
    private volatile static boolean isSearching = false;
    private static boolean done = false;
    private volatile static String fileToSearch;
    private volatile static String fileToDownload;
    private volatile static String byeMessage = "";
    private volatile static String ipOfSender;
    private volatile static int portOfSender;

    private JButton search;  //Buttons
    private JButton dload;
    private JButton close;

    private JList jl;   // List that will show found files
    private JLabel label; //Label "File Name
    private static JTextField tf, tf2; // Two textfields: one is for typing a file name, the other is just to show the selected file
    private static DefaultListModel listModel; // Used to select items in the list of found files

    public Peer(String ip, int port, int score) {
        super("Peer GUI: " + port);
        this.ip = ip;
        this.port = port;
        this.score = score;
        fs = new ArrayList<>();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startGUI();
        //this.fs = fs;
//        javax.swing.SwingUtilities.invokeLater(new Runnable() {
//            public void run() {
//                startGUI();
//            }
//        }
//        );
    }

    public String getIP() {
        return ip;
    }

    public ArrayList<FData> getFdata() {
        return fs;
    }

    public int getScore() {
        return score;
    }

    public int getPort() {
        return port;
    }

    public void setScore(int n) {
        score = n;
    }

    @Override
    public String toString() {
        return "<" + ip + ", " + port + ", " + score + ">";
    }
//    public ArrayList<FData> getList(){
//        return fs;
//    }

    public void startGUI() {
        setLayout(null);
        setSize(500, 600);

        label = new JLabel("File name:");
        label.setBounds(50, 50, 80, 20);
        add(label);

        tf = new JTextField();
        tf.setBounds(130, 50, 220, 20);
        add(tf);

        search = new JButton("Search");
        search.setBounds(360, 50, 80, 20);
        search.addActionListener(this);
        add(search);

        listModel = new DefaultListModel();
        jl = new JList(listModel);

        JScrollPane listScroller = new JScrollPane(jl);
        listScroller.setBounds(50, 80, 300, 300);

        add(listScroller);

        dload = new JButton("Download");
        dload.setBounds(200, 400, 130, 20);
        dload.addActionListener(this);
        add(dload);

        tf2 = new JTextField();
        tf2.setBounds(200, 430, 130, 20);
        add(tf2);

        close = new JButton("Close");
        close.setBounds(360, 470, 80, 20);
        close.addActionListener(this);
        add(close);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == search) { //If search button is pressed show 25 randomly generated file info in text area 
            fileToSearch = tf.getText();
            System.out.println("fileToSearch " + fileToSearch);
            isSearching = true;
            System.out.println("Is searching?: " + isSearching);

        } else if (e.getSource() == dload) {   //If download button is pressed get the selected value from the list and show it in text field
            tf2.setText(jl.getSelectedValue().toString());
            
            fileToDownload = tf2.getText();
        } else if (e.getSource() == close) { //If close button is pressed exit
            isDone = true;
            //System.exit(0);
        }

    }

    public static void main(String[] args) throws IOException {
        ServerSocket welcSocket = new ServerSocket(0);
        Socket s = new Socket(FileTracker.FileTrackerIP, FileTracker.FileTrackerPort);
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        BufferedReader dis = new BufferedReader(new InputStreamReader(s.getInputStream()));
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        fs = new ArrayList<>();

        Peer ex = new Peer(welcSocket.getInetAddress().getHostName(), welcSocket.getLocalPort(), 0);
        ex.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close the window if x button is pressed

        File[] files = new File("/Users/zuldyz/NetBeansProjects/FileSharing/src/filesharing/SharedFiles3").listFiles();

        for (File f : files) {
            if (f.isFile() && !f.getName().equals(".DS_Store")) {

                int lastIndexOfDot = f.getName().lastIndexOf('.');

                String fileExtension = null;
                if (lastIndexOfDot > 0) {
                    fileExtension = f.getName().substring(lastIndexOfDot + 1);
                }

                long timestamp = f.lastModified();
                FData file = new FData(f.getName(), fileExtension, (int) f.length(), new Date(timestamp).toString(), "172.20.10.4", welcSocket.getLocalPort());

                fs.add(file);
                System.out.println(file);
                System.out.println(f.getName() + "\n");
            }

        }

        Thread listenPeers = new Thread(new Runnable() {
            @Override
            public void run() {

                while (done == false) {
                    try {
                        Socket sock = welcSocket.accept();
                        System.out.println("New client has arrived: \n" + sock.getPort());
                        RequestHandler clThread = new RequestHandler(sock, files);
                        Thread td = new Thread(clThread);
                        td.start();
                    } catch (IOException ex) {
                        System.out.println("Cannot accept!");
                    }

                }
            }

        });

        Thread writeTo = new Thread(new Runnable() {
            @Override
            public void run() {
                String msg = "empity";
                while (done == false) {

                    // read the message to deliver.
                    try {
                        //System.out.println("Accep: " + isAccepted + " isSearching: " + isSearching);
                        if (isAccepted == true && isSearching == true) {
                            msg = "SEARCH: " + fileToSearch;
                            System.out.println("message -" + msg);
                            dos.writeBytes(msg + "\n");
                            isSearching = false;
                        }
                        if (isDone == true) {
                            done = true;
                            msg = "BYE";
                            byeMessage = "BYE";
                            System.out.println("Bye message: " + byeMessage);
                            dos.writeBytes(msg + "\n");
                        }

//                        if (isSearching == true) {
//                            System.out.println("I am going to download!");
//                            downloadFile(msg);
//                            isSearching = false;
//
//                        }
                    } catch (IOException ex) {
                        System.out.println("Error!");
                    }
                    //System.out.println(msg);
                }
            }
        });

        // readMessage thread
        Thread readMessage = new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    dos.writeBytes("HELLO" + "\n");
                } catch (IOException ex) {
                    System.out.println("Cannot write!");
                }
                while (done == false) {
                    try {
                        // read the message sent to this client

                        String msg = dis.readLine();
                        if (msg == null) {
                            System.out.println("I am going to leave. Goodbye!");
                            System.exit(0);
                        }
                        if (byeMessage.equals("BYE")) {
                            done = true;
                        }
                        String strs[] = msg.split(":");
                        System.out.println(msg);
                        if (msg.equals("HI")) {
                            isAccepted = true;
                            System.out.println(isAccepted);

                            System.out.println(fs);

                            dos.writeBytes(fs + "\n");
                        } else if (msg.startsWith("FOUND")) {
                            System.out.println("I am going to download!");
                            downloadFile(msg);
                        
                        }else if(msg.startsWith("NOT FOUND")){
                            listModel.clear();
                            listModel.insertElementAt("404 NOT FOUND", 0);
                        }

                    } catch (IOException e) {

                        e.printStackTrace();
                    }
                }
            }

            private void downloadFile(String msg) {
                String s1[] = msg.split("<");
                String ip = "";
                int port = 0, score, size = 0;
                String type = "", lastModif;
                //ArrayList<Peer> peersWhoShare = new ArrayList<>();
                String[] arrs = new String[100];
                int z = 0;
                for (int i = 1; i < s1.length; i++) {

                    String temp = "<" + s1[i];
                    arrs[z] = temp;
                    System.out.println("temp - " + temp);
                    z++;
                }

                listModel.clear();
                for (int k = 0; k < z; k++) {
                    listModel.insertElementAt(arrs[k], k);
                    System.out.println("list" + arrs[k]);
                }

                while (fileToDownload == null) {
                    if (fileToDownload != null) {
                        break;
                    }
                }

                System.out.println("File to download: " + fileToDownload);
                String s3[] = fileToDownload.split("<");
                
                fileToDownload = null;
                
                //ArrayList<Peer> peersWhoShare = new ArrayList<>();
                String s2[] = s3[1].split(", ");
                type = s2[0];
                size = Integer.parseInt(s2[1]);
                lastModif = s2[2];
                ip = s2[3];
                String s4[] = s2[4].split(">");
                port = Integer.parseInt(s4[0]);
                String s5[] = s2[4].split(":");
                String s6[] = s5[1].split(" ");
                score = Integer.parseInt(s6[0]);
                ipOfSender = ip;
                portOfSender = port;
                //FData data = new FData(fileToSearch, type, size, lastModif, ip, port);
                //Peer p = new Peer(ip, port, score);
                //p.getFdata().add(data);
                //peersWhoShare.add(p);
                String record = "!" + ip + ", " + port + ", " + score + "!";
                System.out.println(record);

                System.out.println("Peer: " + ip + " " + port);

                String message = "DOWNLOAD: " + fileToSearch + " " + type + " " + size + "\n";
                //System.out.println(message);

                Socket peerSock = null;

                try {
                    System.out.println("Ip of sender: " + ipOfSender + " Port of sender: " + portOfSender);
                    peerSock = new Socket(ipOfSender, portOfSender);
                } catch (IOException ex) {
                    System.out.println("Cannot open the socket!");
                }

                try {
                    OutputStream toPeer = peerSock.getOutputStream();
                    InputStream fromPeer = peerSock.getInputStream();
                    int n;
                    toPeer.write(message.getBytes());
                    byte buf[] = new byte[5];
                    n = fromPeer.read(buf);
                    //String rec = fromPeer.readLine();
                    String rec = new String(buf, 0, n);
                    System.out.println("Rec: " + rec);
                    String strs[] = rec.split(":");

                    if (strs[0].equals("FILE")) {
                        String scoreMsg = "SCORE of " + ipOfSender + " " + portOfSender + ": 1";
                        dos.writeBytes(scoreMsg + "\n");
                        FileOutputStream toFile = new FileOutputStream("/Users/zuldyz/NetBeansProjects/FileSharing2/src/filesharing/Downloads/" + fileToSearch);
                        byte[] bytes = new byte[size];
                        int cc;
                        while ((cc = fromPeer.read(bytes)) > 0) {
                            toFile.write(bytes, 0, cc);
                        }
                        
                        tf2.setText("Downloaded!");
                    } else if (rec.startsWith("NO!")) {
                        tf2.setText("Denied!");
                        String scoreMsg = "SCORE of " + ipOfSender + " " + portOfSender + ": 0";
                        System.out.println("NO?");
                        dos.writeBytes(scoreMsg + "\n");
//                        System.out.println("I received: " + rec);
//                        toPeer.close();
//                        fromPeer.close();
//                        peerSock.close();
                        //done = true;
                    }
                    System.out.println("I received: " + rec);
                    toPeer.close();
                    fromPeer.close();
                    peerSock.close();

                } catch (IOException ex) {
                    System.out.println("Cannot write to peer!");
                }
               
            }

        }
        );

        writeTo.start();

        readMessage.start();

        listenPeers.start();
        if (done
                == true) {
            dis.close();
            in.close();
            dos.close();
            s.close();
            welcSocket.close();
            System.exit(-1);
        }
    }
}


