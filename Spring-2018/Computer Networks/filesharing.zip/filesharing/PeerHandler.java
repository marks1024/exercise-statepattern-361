/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesharing;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author zuldyz
 */
public class PeerHandler implements Runnable {

    private Socket sock;
    private BufferedReader dis;
    private DataOutputStream dos;
    private HashMap<String, Integer> h;
    private Client c;

    public PeerHandler(Socket sock, int num) {
        try {
            this.sock = sock;

            dis = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            dos = new DataOutputStream(sock.getOutputStream());

        } catch (IOException ex) {
            System.out.println("Cannot open stream!");
        }
        //FileTracker ft = new FileTracker();
    }

    @Override
    public void run() {
        String received;
        System.out.println("Hey!");
        boolean done = false;
        try{
        while (done == false) {
            try {
                received = dis.readLine();
                done = handleMessages(received);

            } catch (IOException ex) {
                System.out.println("Cannot read!");
            }

        }
        }finally{
            try {
                System.out.println("I am closing the socket");
                dis.close();
                dos.close();
                sock.close();
            } catch (IOException ex) {
                System.out.println("Error closing this socket!");
            }
        }
    }

    private boolean handleMessages(String received) {

        String strs[] = received.split(" ", 2);
        if (received.equals("HELLO")) {
            String message = "HI\n";
            try {
                dos.writeBytes(message);

            } catch (IOException ex) {
                System.out.println("Cannot write!");
            }
            System.out.println(received);
 
        } else if (strs[0].equals("SEARCH:")) {
            String fname = strs[1];
            sendFilesHolders(fname);
        } else if (strs[0].startsWith("SCORE")) {
            adjustScores(received);

        } else if (strs[0].equals("BYE")) {

            FileTracker.removeRecord(c);

            return true;

        } else {
            System.out.println(received);

            if (received.equals("[]") || received.equals("")) {
                System.out.println("EMPTY");
                try {
                    sock.close();
                } catch (IOException ex) {
                    System.out.println("Failed to close the socket");
                }
                return true;
            }
            registerUser(received);
        }

        return false;
    }

    private void registerUser(String received) {
        String s1[] = received.split("<");
        String ip = "";
        String port = "";
        for (int i = 1; i < s1.length; i++) {

            String s2[] = s1[i].split(", ");
            String fname = s2[0];
            String type = s2[1];
            String size = s2[2];
            String date = s2[3];
            ip = s2[4];
            port = s2[5];
            String s4[] = port.split(">");
            port = s4[0];
            if (i == 1) {
                c = new Client(ip, Integer.parseInt(port), 0);
                FileTracker.addPeer(c);
            }

            String rec = "<" + type + ", " + size + ", " + date + ", " + ip + ", " + port + ">";
            c.getFdata().add(rec);
            FileTracker.addRecord(fname, rec);

        }

        System.out.println("My records: " + c.getFdata());

    }

    private void sendFilesHolders(String fname) {
        String message;
        if (FileTracker.searchRecords(fname) == true) {
            System.out.println(FileTracker.records.get(fname));
            String s1[] = FileTracker.records.get(fname).toString().split("<");
            System.out.println("");
            String ip = "";
            String port = "";
            message = "FOUND:";
            for (int i = 1; i < s1.length; i++) {
                String s2[] = s1[i].split(", ");

                ip = s2[3];
                port = s2[4];
                String s4[] = port.split(">");
                port = s4[0];

            }

            for (Client peer : FileTracker.peers.get(ip)) {
                System.out.println("Peers:" + FileTracker.peers);
                if (peer.getIP().equals(ip) && peer.getPort() == Integer.parseInt(port)) {
                    message += FileTracker.records.get(fname) + ":" + peer.getScore() + " ";
                    System.out.println("My message is: " + message);

                }
            }
        } else {
            message = "NOT FOUND";
        }

        try {
            System.out.println("Going to send the information...");
            dos.writeBytes(message + "\n");
            dos.flush();
        } catch (IOException ex) {
            System.out.println("Cannot write!");
        }

    }

    private void adjustScores(String received) {
        System.out.println("Score message: " + received);
        String str[] = received.split(" ");
        int curr = c.getNumOfRequests();
        c.setNumOfRequests(++curr);
        System.out.println("This curr: " + curr);
        System.out.println("Number of requests: " + c.getNumOfRequests());

        String ipOfSender = str[2];
        System.out.println("Ip: " + ipOfSender);
        String s1[] = str[3].split(":");

        int portOfSender = Integer.parseInt(s1[0]);
        System.out.println("Port: " + portOfSender);
        int score = Integer.parseInt(str[4]);
        System.out.println("Sc: " + score);

        for (Client peer : FileTracker.peers.get(ipOfSender)) {
            double sc = 0;
            if (peer.getIP().equals(ipOfSender) && peer.getPort() == portOfSender) {
                curr = peer.getNumOfUploads();
                peer.setNumOfUploads(curr + score);
                System.out.println("Current: " + curr);
                System.out.println("Uploads number: " + peer.getNumOfUploads());
                if (peer.getNumOfRequests() == 0) {
                    sc = 0.0;
                    System.out.println("No requests? " + peer);
                } else {
                    sc = (peer.getNumOfUploads()*100) / peer.getNumOfRequests();
                    System.out.println("New score: " + peer);
                }
                int finalScore = (int) sc;
                peer.setScore(finalScore);
                System.out.println(peer);
            }
        }

    }

}
