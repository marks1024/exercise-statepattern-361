#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <pthread.h>

#define	QLEN			5
#define	BUFSIZE			4096

#define QSA "QS|ADMIN\r\n"
#define W "WAIT\r\n"
#define QSJ "QS|JOIN\r\n"
#define QSF "QS|FULL\r\n"
#define MYQ "What is the longest river in the world?\r\n"

int numberOfClients = 0;
char *Lname[1000];
int Lnum = 0;
int answer = 0;
pthread_mutex_t  mutex;
pthread_cond_t c;

int passivesock( char *service, char *protocol, int qlen, int *rport );

/*This function is called when write and read are failed. When the client is last it allows anther client to arrive*/
int exitGroup(int ccc, int clientsCount){
    printf("CCC is: %i\n", ccc);
    if(clientsCount == Lnum && ccc <=0){ //case when the last
        pthread_mutex_lock( &mutex );
        numberOfClients--; //increment the number of clients
        clientsCount = numberOfClients;
        pthread_mutex_unlock( &mutex );
    }else{
        pthread_mutex_lock( &mutex );
        numberOfClients--;
        pthread_mutex_unlock( &mutex );
    }
    return clientsCount;
}

void *serveClient(void *arg){
    
    printf( "Hello from thread.\n" );
    fflush( stdout );

     char  buf[BUFSIZE];
    int  ssock = (int)arg;
    int  cc;
    int count = 0;
    int ans = 0;
    /* start working for this guy*/
    
    pthread_mutex_lock( &mutex );
    numberOfClients++; //increment the number of clients
    count = numberOfClients;
    pthread_mutex_unlock( &mutex );

    printf("The number of clients: %i\n", numberOfClients);
    fflush( stdout );
    
    char **splitted; //th pointer to array of strings to handle the answer of client
    splitted = (char**) malloc(100*sizeof(char**));
    Lname[ssock] = (char*) malloc(30*sizeof(char*)); //to strore the name of this particular client
    
    /*Each thread checks the following three conditions:
     1) if it is a first arrived client (number of clients copied to local client's count is equal to one) it becomes an administrator and sends it's name and the group's size
     2) if clients arrive until the total number of clients exceeds the group's size they join the game and their names are saved using socket number
     3) if the number of clients exceeeds the group's size server sends a message that the group is full and disconnects that client by closing socket and exiting the thread*/
    
    /*Client's socket is closed, the thread is exited and the number of clients is decremented whenever the server notices (usually by trying to read or write) that the client disconnects */

        if(count == 1){
            if ( ( cc = write( ssock, QSA, strlen(QSA))) < 0 ){ //Message to Admin
                /* This guy is dead */
                count = exitGroup(cc, count);
                close( ssock ); //close the connection with the server
                pthread_exit( NULL ); //exit thread
               }
        if ( (cc = read( ssock, buf, BUFSIZE )) <= 0 )
        {
            printf( "The client has gone.\n" );
            count = exitGroup(cc, count);
            close(ssock);
            pthread_exit( NULL );
        }
        else
        {
            buf[cc] = '\0';
            printf( "The client says: %s\n", buf );
            char *save;
            char *token;
            /*using safe string tokenizer*/
            token = strtok_r(buf, "|", &save); //pointer to the first element of the splitted string
            int i = 0;
            //loop looks for special symbols, i.e. the pipe symbol
            while(token != NULL){ //store only 100 tokens
                (splitted[i]) = token; //store commands in splitted
                i++;
                token = strtok_r(NULL, "|", &save);
            }
            splitted[i] = NULL;

            strcpy(Lname[ssock], splitted[1]);//the nane of the ADMIN
            Lnum = atoi(splitted[2]); //Group size
            
           printf( "The client's name: %s\n", Lname[ssock]);
            fflush( stdout );
            printf( "The group size: %i\n", Lnum);
            fflush( stdout );
        }
        
            if (( cc = write( ssock, W, strlen(W))) < 0 ){ //WAIT messsage
                /* This guy is dead */
                count = exitGroup(cc, count);
                close(ssock);
                pthread_exit( NULL );
            }
            
        }else if(count <= Lnum){
        
        if (( cc = write( ssock, QSJ, strlen(QSJ))) < 0 ){ //JOIN message
            /* This guy is dead */
            count = exitGroup(cc, count);
            close(ssock);
            pthread_exit( NULL );
        }
        if ( (cc = read( ssock, buf, BUFSIZE )) <= 0 )
        {
            printf( "The client has gone.\n" );
            count = exitGroup(cc, count);
            close(ssock);
            pthread_exit( NULL );
        }
        else
        {
            buf[cc] = '\0';
            char *save;
            char *token;
            token = strtok_r(buf, "|", &save); //pinter to the first element of the splitted string
            int i = 0;
            
            //loop looks for special symbols
            while(token != NULL){ //store only 100 tokens
                (splitted[i]) = token; //store commands in splitted
                i++;
                token = strtok_r(NULL, "|", &save);
            }
            splitted[i] = NULL;
 
           strcpy(Lname[ssock], splitted[1]); //names of clients are stored
           printf( "The client's name: %s\n", Lname[ssock]);
        }
        
        if (( cc = write( ssock, W, strlen(W))) < 0 ){ //Wait message
            /* This guy is dead */
            count = exitGroup(cc, count);
            close(ssock);
            pthread_exit( NULL );
        }
    }else{
        if (( cc = write( ssock, QSF, strlen(QSF))) < 0 ){ //FULL massage
            /* This guy is dead */
            count = exitGroup(cc, count);
        }
        close( ssock); //server is unavailable for extra clients
        pthread_exit( NULL );
    }

    /*If the clients is not the last in the group it goes to sleep via cond_wait where conditional variable is the number of clients.
     If the client is the last one it wakes up all other sleeeping clients and the question from the server sent to all clients st the same time*/
    
    if(count < Lnum){
        pthread_mutex_lock( &mutex );
        while(numberOfClients < Lnum){
            pthread_cond_wait(&c, &mutex);
        }
        pthread_mutex_unlock( &mutex );

    }else{
        pthread_mutex_lock( &mutex );
        pthread_cond_broadcast(&c);
        pthread_mutex_unlock( &mutex );
    }

    if (( cc = write( ssock, MYQ, strlen(MYQ))) < 0 ){
        /* This guy is dead */
        count = exitGroup(cc, count);
        close(ssock);
        pthread_exit( NULL );
    }
    
    /*Another local variable ans is declared and gets the copy of the answer count inside mutex lock.
     If the ans == 1, it means that this client answered first to the server's question and its name stored in Lname[sscock] is printed*/
    if ( (cc = read( ssock, buf, BUFSIZE )) <= 0 )
    {
        printf( "The client has gone.\n" );
        count = exitGroup(cc, count);
        close(ssock);
        pthread_exit( NULL );
    }
    else
    {
        buf[cc] = '\0';
        pthread_mutex_lock( &mutex );
        answer++;
        ans = answer;
        pthread_mutex_unlock( &mutex );

        if(ans == 1){
            printf( "The winner is: %s\n", Lname[ssock]);
            fflush( stdout );
        }
        
    }

    free(splitted);
    free(Lname[ssock]);
    pthread_exit( NULL );
}

int
main( int argc, char *argv[] )
{
    char            *service;
    struct sockaddr_in    fsin;
    int            rport = 0;
    int            alen;
    int            msock;
    int            ssock;
    pthread_t thread;
    int status;
    pthread_mutex_init( &mutex, NULL );
    pthread_cond_init( &c, NULL );

    switch (argc)
    {
        case    1:
            // No args? let the OS choose a port and tell the user
            rport = 1;
            break;
        case    2:
            // User provides a port? then use it
            service = argv[1];
            break;
        default:
            fprintf( stderr, "usage: server [port]\n" );
            exit(-1);
    }

    msock = passivesock( service, "tcp", QLEN, &rport );
        if (rport)
        {
            //    Tell the user the selected port
            printf( "server: port %d\n", rport );
            fflush( stdout );
        }
    
    for (;;)
    {
        int  ssock;
        
        alen = sizeof(fsin);
        ssock = accept( msock, (struct sockaddr *)&fsin, &alen );
                if (ssock < 0)
                {
                    fprintf( stderr, "accept: %s\n", strerror(errno) );
                    break;
                }
                printf( "A client has arrived for echoes.\n" );
                fflush( stdout );
        
        /* start working for this guy
          create thread to handle each client*/
        status = pthread_create(&thread, NULL, serveClient, (void *)ssock);
        if ( status != 0 )
        {
            printf( "pthread_create error %d.\n", status );
            break;
        }
    }
    pthread_mutex_destroy( &mutex );
    pthread_exit( 0 );
    
}




